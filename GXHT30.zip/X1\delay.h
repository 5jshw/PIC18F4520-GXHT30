//��ʱ

#ifndef delay_h
#define delay_h

void Delay10Ms(unsigned char ms);
void DelayMs(unsigned char ms);
void Delay10us(unsigned char us);
void Delayus(unsigned char us);

#endif